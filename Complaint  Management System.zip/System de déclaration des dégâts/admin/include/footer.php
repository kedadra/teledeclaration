	<div class="footer">
		<div class="container">


			<b class="copyright">&copy; 2022 &copy;  </b>
		</div>
	</div>
