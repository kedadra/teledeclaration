 <header class="header black-bg" style="background:#68dff0; border-bottom: 1px solid #68dff0;">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a href="index.html" class="logo"><b>Système de gestion des déclarations</b></a>
                
            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout"  style="background:#428bca;" href="logout.php">Se déconnecter</a></li>
            	</ul>
            </div>
        </header>