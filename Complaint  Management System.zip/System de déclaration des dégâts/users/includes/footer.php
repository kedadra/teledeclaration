 <footer class="site-footer">
          <div class="text-center">
              &copy; 2022 annaba.
              <a href="#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>
